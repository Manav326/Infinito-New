package com.mind.loginregisterapps;

import android.app.Activity;

public class dashboard extends Activity {
}
